<?php
// config/config.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'smartrevision');
define('DB_USER', 'root');
define('DB_PASS', '');

define('URLROOT', 'http://localhost/smartrevision');
define('APPROOT', dirname(__DIR__));

