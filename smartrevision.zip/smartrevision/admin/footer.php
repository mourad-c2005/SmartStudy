</main>
<footer class="admin-footer">
  <p>SmartRevision+ Back Office © 2025 — Administration</p>
</footer>
</body>
</html>
