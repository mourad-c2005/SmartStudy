<h1>Chapitres de <?= htmlspecialchars($data['matiere']['nom']) ?></h1>

<?php if (!empty($_SESSION['admin_logged'])): ?>
    <a href="<?= URLROOT ?>/Chapitre/add/<?= $data['matiere']['id'] ?>" class="btn-start">
        + Ajouter un chapitre
    </a>
<?php endif; ?>

<table class="table-list">
    <tr>
        <th>ID</th>
        <th>Titre</th>
        <th>Actions</th>
    </tr>

    <?php foreach ($data['chapitres'] as $c): ?>
    <tr>
        <td><?= $c['id'] ?></td>
        <td><?= htmlspecialchars($c['titre']) ?></td>
        <td>
            <!-- Bouton pour voir les cours -->
            <a href="<?= URLROOT ?>/Cours/index/<?= $c['id'] ?>">Cours</a>

            <!-- BOUTON QUIZ POUR L'ÉTUDIANT -->
            | <a href="<?= URLROOT ?>/Quiz/index/<?= $c['id'] ?>" class="btn-start">
                Quiz
              </a>

            <!-- CRUD visible seulement admin -->
            <?php if (!empty($_SESSION['admin_logged'])): ?>
                | <a href="<?= URLROOT ?>/Chapitre/edit/<?= $c['id'] ?>">Modifier</a>
                | <a href="<?= URLROOT ?>/Chapitre/delete/<?= $c['id'] ?>"
                     onclick="return confirm('Supprimer chapitre ?');">Supprimer</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
