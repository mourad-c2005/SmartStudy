<h2>Modifier le cours : <?= htmlspecialchars($data['cours']['titre']) ?></h2>

<form method="POST">
    <label>Titre :</label><br>
    <input type="text" name="titre" value="<?= htmlspecialchars($data['cours']['titre']) ?>" required style="width:100%;margin-bottom:10px;"><br>

    <label>Contenu :</label><br>
    <textarea name="contenu" required style="width:100%;height:150px;margin-bottom:10px;"><?= htmlspecialchars($data['cours']['contenu']) ?></textarea><br>

    <label>Lien vidéo :</label><br>
    <input type="text" name="lien_video" value="<?= htmlspecialchars($data['cours']['lien_video']) ?>" style="width:100%;margin-bottom:10px;"><br>

    <h3>Quiz du cours</h3>
    <div id="quiz-container"></div>
    <button type="button" onclick="addQuestion()">Ajouter une question</button><br><br>

    <button type="submit">Mettre à jour le cours et les quiz</button>
</form>

<script>
let quizIndex = 0;
const quizContainer = document.getElementById('quiz-container');

// Charger les quiz existants
const existingQuiz = <?= json_encode($data['quizs'], JSON_UNESCAPED_UNICODE) ?>;
existingQuiz.forEach(q => {
    addQuestion(q);
});

function addQuestion(q = null) {
    const html = `
    <div style="border:1px solid #ccc;padding:10px;margin-bottom:10px;">
        ${q ? `<input type="hidden" name="quiz[${quizIndex}][id]" value="${q.id}">` : ''}
        <label>Question:</label><br>
        <input type="text" name="quiz[${quizIndex}][question]" value="${q ? q.question : ''}" required><br>
        <label>Réponse 1:</label><input type="text" name="quiz[${quizIndex}][rep1]" value="${q ? q.rep1 : ''}" required><br>
        <label>Réponse 2:</label><input type="text" name="quiz[${quizIndex}][rep2]" value="${q ? q.rep2 : ''}" required><br>
        <label>Réponse 3:</label><input type="text" name="quiz[${quizIndex}][rep3]" value="${q ? q.rep3 : ''}" required><br>
        <label>Réponse 4:</label><input type="text" name="quiz[${quizIndex}][rep4]" value="${q ? q.rep4 : ''}" required><br>
        <label>Bonne réponse (1-4):</label><input type="number" name="quiz[${quizIndex}][correcte]" min="1" max="4" value="${q ? q.correcte : 1}" required><br>
    </div>`;
    quizContainer.insertAdjacentHTML('beforeend', html);
    quizIndex++;
}
</script>
