<h1>Cours du chapitre : <?= htmlspecialchars($data['chapitre']['titre']) ?></h1>

<?php if (!empty($_SESSION['admin_logged'])): ?>
    <a href="<?= URLROOT ?>/Cours/add/<?= $data['chapitre']['id'] ?>" class="btn-start">+ Ajouter un cours</a>
<?php endif; ?>

<table class="table-list">
    <tr>
        <th>ID</th><th>Titre</th><th>Actions</th>
    </tr>

    <?php foreach ($data['cours'] as $c): ?>
    <tr>
        <td><?= $c['id'] ?></td>
        <td><?= htmlspecialchars($c['titre']) ?></td>
        <td>
            <a href="<?= URLROOT ?>/Cours/show/<?= $c['id'] ?>">Voir</a>
            <?php if (!empty($_SESSION['admin_logged'])): ?>
                | <a href="<?= URLROOT ?>/Cours/edit/<?= $c['id'] ?>">Modifier</a>
                | <a href="<?= URLROOT ?>/Cours/delete/<?= $c['id'] ?>" onclick="return confirm('Supprimer ce cours?')">Supprimer</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
