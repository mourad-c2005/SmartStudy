<h2>Ajouter un nouveau cours</h2>

<form method="POST">
    <h3>Informations du cours</h3>
    <input type="text" name="titre" placeholder="Titre du cours" required style="width:100%;margin-bottom:10px;"><br>
    <textarea name="contenu" placeholder="Contenu du cours" required style="width:100%;height:150px;margin-bottom:10px;"></textarea><br>
    <input type="text" name="lien_video" placeholder="Lien vidéo" style="width:100%;margin-bottom:10px;"><br>

    <h3>Quiz (questions spécifiques à ce cours)</h3>
    <div id="quiz-container"></div>
    <button type="button" onclick="addQuestion()">Ajouter une question</button><br><br>

    <button type="submit">Ajouter le cours et les quiz</button>
</form>

<script>
let quizIndex = 0;
function addQuestion() {
    const container = document.getElementById('quiz-container');
    const html = `
    <div style="border:1px solid #ccc;padding:10px;margin-bottom:10px;">
        <label>Question:</label><br>
        <input type="text" name="quiz[${quizIndex}][question]" required><br>
        <label>Réponse 1:</label><input type="text" name="quiz[${quizIndex}][rep1]" required><br>
        <label>Réponse 2:</label><input type="text" name="quiz[${quizIndex}][rep2]" required><br>
        <label>Réponse 3:</label><input type="text" name="quiz[${quizIndex}][rep3]" required><br>
        <label>Réponse 4:</label><input type="text" name="quiz[${quizIndex}][rep4]" required><br>
        <label>Bonne réponse (1-4):</label><input type="number" name="quiz[${quizIndex}][correcte]" min="1" max="4" value="1" required><br>
    </div>`;
    container.insertAdjacentHTML('beforeend', html);
    quizIndex++;
}
</script>
