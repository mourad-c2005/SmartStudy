// public/js/script.js
// petit utilitaires JS communs (ex: confirmations)
document.addEventListener('DOMContentLoaded', function(){
  // nothing for now; comportement quiz est dans la vue quiz
});
